//==============================================================================
//module enable:

#include "TCPServer/TCPServer_ComponentConfig.h"
#ifdef TCP_SERVER_LWIP_COMPONENT_ENABLE
//==============================================================================
//header:

#ifndef _TCP_SERVER_LWIP_COMPONENT_H
#define _TCP_SERVER_LWIP_COMPONENT_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
//includes:

#include "TCPServer_LWIP_ComponentConfig.h"
#include "TCPServer/Controls/TCPServer.h"
//==============================================================================
//defines:


//==============================================================================
//functions:

xResult TCPServerLWIPComponentInit(void* parent);

void _TCPServerLWIPComponentHandler();
void _TCPServerLWIPComponentTimeSynchronization();
void _TCPServerLWIPComponentEventListener(TCPServerT* server, TCPServerEventSelector selector, void* arg, ...);
xResult _TCPServerLWIPComponentRequestListener(TCPServerT* server, TCPServerRequestSelector selector, void* arg, ...);
void _TCPServerLWIPComponentIRQListener(TCPServerT* port, ...);
//==============================================================================
//import:


//==============================================================================
//override:

#define TCPServerLWIPComponentHandler() TCPServer(&TCPServerWIZspi)
#define TCPServerLWIPComponentTimeSynchronization() TCPServer(&TCPServerWIZspi)

#define TCPServerLWIPComponentIRQListener(server, ...) _TCPServerComponentLWIPListener(server, ##__VA_ARGS__)

#define TCPServerLWIPComponentEventListener(server, selector, arg, ...) _SerialPortUARTComponentEventListener(port, selector, arg, ##__VA_ARGS__)
#define TCPServerLWIPComponentRequestListener(server, selector, arg, ...) _SerialPortUARTComponentRequestListener(port, selector, arg, ##__VA_ARGS__)
//==============================================================================
//export:

extern TCPServerT TCPServerLWIP;
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif //_TCP_SERVER_LWIP_COMPONENT_H
#endif //TCP_SERVER_LWIP_COMPONENT_ENABLE
