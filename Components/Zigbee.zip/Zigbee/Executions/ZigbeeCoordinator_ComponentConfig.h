//==============================================================================
//module enable:

#include "Zigbee/Zigbee_ComponentConfig.h"
#ifdef ZIGBEE_COORDINATOR_COMPONENT_ENABLE
//==============================================================================
//header:

#ifndef _ZIGBEE_CCOORDINATOR_COMPONENT_CONFIG_H
#define _ZIGBEE_CCOORDINATOR_COMPONENT_CONFIG_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
//includes:


//==============================================================================
//defines:

#define ZIGBEE_MAC_ADDRESS
//==============================================================================
//selector:


//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif //_ZIGBEE_CCOORDINATOR_COMPONENT_CONFIG_H
#endif //ZIGBEE_CCOORDINATOR_COMPONENT_ENABLE
